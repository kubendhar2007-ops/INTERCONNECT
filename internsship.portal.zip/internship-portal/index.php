```php
<?php
session_start();

require_once __DIR__ . '/config/database.php';

$data = db_load();

$internships = $data['internships'] ?? [];
$companies   = $data['companies'] ?? [];
$students    = $data['students'] ?? [];

$openCount = count(array_filter(
    $internships,
    function ($internship) {
        return ($internship['status'] ?? 'Open') === 'Open';
    }
));

$companyCount = count($companies);
$studentCount = count($students);

$isLoggedIn = isset($_SESSION['user_id']);
$role = $_SESSION['role'] ?? '';

$dashboardUrl = 'login.php';

if ($isLoggedIn) {
    if ($role === 'student') {
        $dashboardUrl = 'student/dashboard.php';
    } elseif ($role === 'company') {
        $dashboardUrl = 'company/dashboard.php';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>InternHub | Internship Portal</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <!-- Navigation Bar -->
    <nav class="navbar">

        <a class="logo" href="index.php">
            Intern<span>Hub</span>
        </a>

        <div class="nav-links">

            <a href="index.php">Home</a>

            <?php if ($isLoggedIn): ?>

                <a href="<?= htmlspecialchars($dashboardUrl) ?>">
                    Dashboard
                </a>

                <a href="logout.php">Logout</a>

            <?php else: ?>

                <a href="login.php">Sign in</a>

                <a class="nav-button" href="register.php">
                    Create account
                </a>

            <?php endif; ?>

        </div>

    </nav>


    <!-- Hero Section -->
    <section class="hero">

        <div class="hero-content">

            <p class="eyebrow">
                COLLEGE INTERNSHIP PLATFORM
            </p>

            <h1>
                Learn. Apply.<br>
                <span>Get noticed.</span>
            </h1>

            <p class="hero-text">
                A simple internship portal where students can
                discover opportunities, apply for internships,
                and track their applications. Companies can
                publish openings and manage applicants easily.
            </p>

            <div class="hero-buttons">

                <?php if ($isLoggedIn): ?>

                    <a class="btn primary"
                       href="<?= htmlspecialchars($dashboardUrl) ?>">
                        Go to Dashboard
                    </a>

                <?php else: ?>

                    <a class="btn primary" href="register.php">
                        Get started
                    </a>

                    <a class="btn secondary" href="login.php">
                        Sign in
                    </a>

                <?php endif; ?>

            </div>

        </div>


        <!-- Statistics Card -->
        <div class="hero-card">

            <p class="eyebrow">PLATFORM OVERVIEW</p>

            <h3>
                Everything your internship journey needs
            </h3>

            <div class="journey">

                <div>
                    <b>
                        <?= str_pad(
                            (string) $openCount,
                            2,
                            '0',
                            STR_PAD_LEFT
                        ) ?>
                    </b>
                    <span>Open opportunities</span>
                </div>

                <div>
                    <b>
                        <?= str_pad(
                            (string) $studentCount,
                            2,
                            '0',
                            STR_PAD_LEFT
                        ) ?>
                    </b>
                    <span>Student profiles</span>
                </div>

                <div>
                    <b>
                        <?= str_pad(
                            (string) $companyCount,
                            2,
                            '0',
                            STR_PAD_LEFT
                        ) ?>
                    </b>
                    <span>Hiring companies</span>
                </div>

                <div>
                    <b>24/7</b>
                    <span>Application access</span>
                </div>

            </div>

        </div>

    </section>


    <!-- Features Section -->
    <section class="section">

        <div class="section-title">

            <p class="eyebrow">WHY INTERNHUB</p>

            <h2>One clean workspace.</h2>

        </div>


        <div class="feature-grid">

            <div class="feature-card">

                <div class="feature-icon">01</div>

                <h3>Build Your Profile</h3>

                <p>
                    Add your education, skills, personal details,
                    and resume to create your student profile.
                </p>

            </div>


            <div class="feature-card">

                <div class="feature-icon">02</div>

                <h3>Discover Internships</h3>

                <p>
                    Explore internship opportunities by role,
                    company, and location.
                </p>

            </div>


            <div class="feature-card">

                <div class="feature-icon">03</div>

                <h3>Track Applications</h3>

                <p>
                    Check your application progress and view
                    updates from companies.
                </p>

            </div>


            <div class="feature-card">

                <div class="feature-icon">04</div>

                <h3>Hire Smarter</h3>

                <p>
                    Companies can post internship openings
                    and manage student applications.
                </p>

            </div>

        </div>

    </section>


    <!-- Footer -->
    <footer>
        &copy; <?= date('Y') ?> InternHub.
        College Internship Portal.
    </footer>


    <script src="js/validation.js"></script>

</body>

</html>
```