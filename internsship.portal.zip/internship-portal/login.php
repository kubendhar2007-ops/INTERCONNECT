```php
<?php

session_start();

require_once __DIR__ . '/config/database.php';

$data = db_load();

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim($_POST['email'] ?? '');
    $password = (string) ($_POST['password'] ?? '');

    if ($email === '' || $password === '') {

        $error = 'Please enter your email and password.';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = 'Please enter a valid email address.';

    } else {

        $user = db_find_user_by_email($data, $email);

        if (
            !$user ||
            !isset($user['password']) ||
            !password_verify($password, $user['password'])
        ) {

            $error = 'Invalid email or password.';

        } elseif (
            !isset($user['id'], $user['name'], $user['role']) ||
            !in_array($user['role'], ['student', 'company'], true)
        ) {

            $error = 'Invalid account details.';

        } else {

            session_regenerate_id(true);

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['role'] = $user['role'];

            if ($user['role'] === 'student') {

                header('Location: student/dashboard.php');
                exit;

            } else {

                header('Location: company/dashboard.php');
                exit;

            }
        }
    }
}

function e($value)
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Sign In | InternHub</title>

    <link rel="stylesheet" href="css/style.css">

</head>

<body class="auth-page">

    <div class="auth-container">

        <div class="auth-brand">

            <a href="index.php" class="logo">
                Intern<span>Hub</span>
            </a>

            <p class="eyebrow" style="margin-top: 55px;">
                WELCOME BACK
            </p>

            <h1>Your next opportunity is waiting.</h1>

            <p>
                Sign in to manage your profile, explore
                internships, and track your applications.
            </p>

        </div>


        <div class="auth-card">

            <h2>Sign In</h2>

            <p class="muted">
                Enter your registered account details.
            </p>

            <?php if ($error !== ''): ?>

                <div class="alert error" role="alert">
                    <?= e($error) ?>
                </div>

            <?php endif; ?>

            <form
                method="POST"
                action="login.php"
                onsubmit="return validateLogin()"
            >

                <label for="email">
                    Email Address
                </label>

                <input
                    type="email"
                    name="email"
                    id="email"
                    value="<?= e($email) ?>"
                    placeholder="you@example.com"
                    autocomplete="email"
                    required
                >

                <label for="password">
                    Password
                </label>

                <input
                    type="password"
                    name="password"
                    id="password"
                    placeholder="Enter your password"
                    autocomplete="current-password"
                    required
                >

                <button
                    class="btn primary full"
                    type="submit"
                >
                    Sign In
                </button>

            </form>

            <p class="auth-bottom">
                New to InternHub?
                <a href="register.php">Create an account</a>
            </p>

            <p class="auth-bottom">
                <a href="index.php">Back to Home</a>
            </p>

        </div>

    </div>

    <script src="js/validation.js"></script>

</body>

</html>
```